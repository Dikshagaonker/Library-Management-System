
class Library:
    def __init__(self,Count_book,name):
        self.Count_book_dict = Count_book
        self.name = name
        self.bookdict = {}
        self.max_book_count = {}
        
        
    def display_books(self): 
        for books in self.Count_book_dict.items():
            print(books)
