
from User import User
class System(User):
    def __init__(self,username,password,librarian_id):
        self.librarian_id = librarian_id
       
        
    def add_book(self,library,book_name,quantity,author,ISBN,subject):
        if quantity>0:
            if book_name in library.Count_book_dict.keys():
                library.Count_book_dict[book_name][0]+=quantity
            else:
                library.Count_book_dict.update({book_name:[quantity,author,ISBN,subject]})
                print(" The book has been added to library.")
        else:
            print("Please enter postive integer number.")
            
            
    def removeBook(self,library,book_name,quantity,author,ISBN,subject):
        if quantity>0:
            if book_name in library.Count_book_dict.keys():
                if library.Count_book_dict[book_name][0]>=1:
                    library.Count_book_dict[book_name][0]-=quantity
                    if library.Count_book_dict[book_name][0] < 0:
                        library.Count_book_dict[book_name][0]+=quantity
                        print("Please enter correct quantity of book. we have only {} books of {}".format(library.Count_book_dict[book_name][0],book_name))
                    else:
                        print("This book has been removed successfully.")
                else:
                    library.Count_book_dict.pop(book_name)
                    print("sorry we don't have any books os {} in our libraray".format(book_name))
            else:
                print("please Enter correct book_name or quantity")
        else:
            print("please Enter postive integer number")
