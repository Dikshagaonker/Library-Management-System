from datetime import date,timedelta
class User:
    def __init__(self,username,password,user):
        self.username = username
        self.password = password
        self.user = user
        
class Member(User):
    def __init__(self,username,password,user,member_id):
        super().__init__(username,password,user)
        self.member_id = member_id
        self.max_book_count = {}
        self.bookdict = {}
        
    def Count_book(self,user,book):
        if user not in self.max_book_count:
            self.max_book_count[user] = [book]
            return len(self.max_book_count[user])
        else:
            if len(self.max_book_count[user])<=1:
                self.max_book_count[user].append(book)
                return len(self.max_book_count[user])
            else:
                return len(self.max_book_count[user])
            
    def lend_book(self,library,book,user):   
            if book in library.Count_book_dict.keys():
                if library.Count_book_dict[book][0]>=1:
                    if (book,user) not in self.bookdict.keys():
                        if not self.cheack_pervious_fine(book,user):
                            if self.Count_book(user,book)<=2:
                                lend_date = date.today()
                                return_date = date.today()+timedelta(days = 7)
                                self.bookdict.update({(book,user):return_date})
                                library.Count_book_dict[book][0] -= 1
                                for value in self.bookdict.keys():
                                    if value == (book,user):
                                        print("{} book is issued to your name {} on {}. You can get the book".format(value[0],value[1],lend_date))
                                        print("You have now 7 days to read the book. Kindly return book on time otherwise 10 rupess/day fine will be charged.")
                                        print(self.max_book_count)
                            else:
                                print("You can issue maximum 2 books only.")
                        else:
                            print("You have to pay to fine first then you will be able to lend book")
                    else:
                        print("This book is already been issued on your name.")
                else:
                    print("Sorry! this book copies are out of stock.")
            else:
                print("Sorry! this book is not available in our library.")


            
    def cheack_pervious_fine(self,book,user):
        current_date = date.today()
        for key,value in self.bookdict.items():
            if key[1]==user:
                return_date = self.bookdict[key]
                if current_date > return_date:
                    delay_days = (current_date - return_date).days
                    total_fine = delay_days*10
                    return total_fine
                else:
                    return 0 
                
    def return_book(self,library,book,user):
        if (book,user)in self.bookdict.keys():
            return_date =  self.bookdict[(book,user)]
            current_date = date.today()
            if current_date > return_date:
                delay_days = (current_date - return_date).days
                total_fine = delay_days*10
                print("Please pay fine,you have to pay {} rupess." .format(total_fine))  
            else:
                self.max_book_count[user].remove(book)
                self.bookdict.pop((book,user))
                library.Count_book_dict[book][0] += 1
                print("The book has been sucessfully returned.")
        else:
            print("Kindly provide correct username and the book name.")
            
   
            
    def cheack_fine(self,library,book,user):
        if (book,user)in self.bookdict.keys():
            return_date =  self.bookdict[(book,user)]
            current_date = date.today()
            if current_date > return_date:
                delay_days = (current_date - return_date).days
                total_fine = delay_days*10
                print("Kindly pay fine,you have to pay {} rupess." .format(total_fine))
            else:
                print("You don't need to pay fine.")
        else:
            print("Enter correct information.")
