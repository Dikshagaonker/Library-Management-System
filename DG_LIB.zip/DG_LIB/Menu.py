import sys
class Setmenu:
    def Search_by_Name(self,Library,book_name):
        for key,value in Library.Count_book_dict.items():
           if book_name in Library.Count_book_dict.keys():
                    print("we are fetching book details on the basis of your request.")
                    print("\n")
                    print("book_name: {} and other details like  quantity,author_name, ISBN_number,Subject respectivey: {}".format(book_name,Library.Count_book_dict[book_name]))
                    print("\n")
                    print("To proceed further enter your choice:")
                    choice = input("Proceed/No: ")
                    if choice == "Proceed":
                        break
                    else:
                        print("you are exiting from system")
                        sys.exit()
           else:
                print("we don't have have this book in our library please cheack your input")
                break

    
    def Search_by_Author(self,Library,Author):
        for key,value in Library.Count_book_dict.items():
            if Author in value[1]:
                print("we are fetching book deatails on the basis of your request.")
                print("\n")
                print("book_name: {} and Other details like  quantity,author_name,ISBN_number,Subject respectivey: {}".format(key,value))
                print("\n")
                print(" To proceed further enter your choice:")
                choice = input("Proceed/No: ")
                if choice == "Proceed":
                    break
                else:
                    print("you are exiting from system")
                    sys.exit()
        else:
            print("we don't have have this book in our library please cheack your input")
            
    def Search_by_ISBN(self,Library,ISBN):
        for key,value in Library.Count_book_dict.items():
            if ISBN in value[2]:
                print("we are fetching book deatails on the basis of your quary")
                print("\n")
                print("book_name: {} and other details like  quantity,author_name,ISBN_number,Subject respectivey: {}".format(key,value))
                print("\n")
                print(" To proceed further enter your choice:")
                choice = input("Proceed/No: ")
                if choice == "Proceed":
                    break
                else:
                    print("you are exiting from system")
                    sys.exit()
        else:
            print("we don't have have this book in our library please cheack your input")
            
    

    def Search_by_Subject(self,Library,Subject):
        for key,value in Library.Count_book_dict.items():
            if Subject in value[3]:
                print("we are fetching book deatails on the basis of your quary")
                print("\n")
                print("book_name: {} and Other details like  quantity,author_name,ISBN_number,Subject respectivey: {}".format(key,value))
                print("\n")
                print("To proceed further enter your choice:")
                choice = input("Proceed/No: ")
                if choice == "Proceed":
                    break
                else:
                    print("you are exiting from system")
                    sys.exit()
        else:
            print("we don't have have this book in our library please cheack your input")


                
