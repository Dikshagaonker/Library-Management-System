#LIBRARY MANAGEMENT SYSTEM

import sys
from Library import Library
from User import Member
from Menu import Setmenu  
from Libsystem import System 
        
library = Library({'Let Us Python':[7,'Yashavant Kanetkar','9388511565','Engineering'],
                  'Anatomy':[10,'Kasi S.N','8123911211','Medecine'],
                  'The Code of Criminal Procedure':[15,'S.N.Misra','9384961779','Law'],
                  'The Economics Book':[5,'DK','1409376419','Economics']},"Central Library" )
m1 = Member("Diksg13","dv123","Diksha","105")
menu = Setmenu()
while(True):
    print("""
        _WelLcome to the Central_Library_Panjim__
        Please enter your choice.
        \n
     1. Display_books_available.
     2. Issue_book.
     3. Return_book.
     4. Fine_Payment.
     5. Search_book_By_Name.
     6. Search_book_By_Author.
     7. Search_book_By_ISBN_Number.
     8. Search_book_By_Sbuject.
     \n
     System Task : To add_book & Remove_book kindly login with system_id.
     9. Add_book.
     10.Remove_book.
     """)
  

    user_choice = input()
    if user_choice not in ["1","2","3","4","5","6","7","8","9","10"]:
        print("please Enter correct choice \n")
        continue
    else:
        user_choice = int(user_choice)
        if user_choice == 1:
            print("The books available in Central_Library_Panjim are as follows:")
            library.display_books()
            print("\n")
            
        elif user_choice == 2:
            book = input("Enter the name of the book you want to issue :")
            user = input("Enter your name:")
            m1.lend_book(library,book,user)
            print("\n")

        elif user_choice == 3:
            book = input("Enter the name of the book you want to return :")
            user = input("Enter your name:")
            m1.return_book(library,book,user)
            print("\n")
            
        elif user_choice == 4:
            book = input("Enter the name of the book having fine :")
            user = input("Enter your name:")
            m1.cheack_fine(library,book,user)
            print("\n")
            
        elif user_choice == 5:
            book_name = input("Enter the name of book: ")
            menu.Search_by_Name(library,book_name)
            print("\n")
            
       
        elif user_choice == 6:
            Author = input("Enter the name of author: ")
            menu.Search_by_Author(library,Author)
            print("\n")
         
         
        elif user_choice == 7:
            ISBN = input( "Enter the ISBN Number." )
            menu.Search_by_ISBN(library,ISBN)
            print("\n")
        
        elif user_choice == 8:
            Subject = input("Enter the name of subject: ")
            menu.Search_by_Subject(library,Subject)
            print("\n")


            
        elif user_choice == 9:
            username = input("username: ")
            password = input("password: ")
            libsys = System(username,password,"105")
            print(" You have successfully logged in with system id.")
            print("You can now proceed to add book in the library")
            print("\n")
            book_name = input("Enter the name of the book to be added back: ")
            quantity = int(input("Enter quantity of book to be added back: "))
            author = input("Enter the name of  book author: ")
            ISBN = input("Enter the book ISBN number: ")
            subject = input("Enter the subject book belongs to: ")
            libsys.add_book(library,book_name,quantity,author,ISBN,subject)
            print("\n")
            
        elif user_choice == 10:
            username = input("username: ")
            password = input("password: ")
            libsys = System(username,password,"105")
            print("You have successfully logged in with system id.")
            print("You can now proceed to remove book from the library")
            print("\n")
            book_name = input("Enter the name of the book to be removed: ")
            quantity = int(input("Enter quantity of book to be removed: "))
            author = input("Enter the name of  book author: ")
            ISBN = input("Enter the book ISBN number: ")
            subject = input("Enter the subject book belongs to: ")
            libsys.removeBook(library,book_name,quantity,author,ISBN,subject)
            print("\n")
        else:
            print("Invalid option entered.")
            
        print("Press key 'q' to quit or key  'c' to continue.")
        choice = ""
        while(choice!= "c" and choice != "q"):
            choice = input()
            if choice == "c":
                continue
            elif choice == "q":
                sys.exit()

